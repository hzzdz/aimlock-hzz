import SwiftUI

@main
struct AuroraIOSApp: App {

    @State private var licenseInfo: LicenseInfo? = LicenseService.loadCached()
    @State private var statusResult: AppStatusResult = .allowed
    @State private var statusChecked = false

    var body: some Scene {
        WindowGroup {
            contentView
                .preferredColorScheme(.dark)
                .task {
                    UninstallDetector.setup()

                    // Run kernel exploit on background thread
                    await Task.detached(priority: .userInitiated) {
                        _ = KernelExploit.run()
                    }.value

                    if let cached = licenseInfo {
                        let ok = await LicenseService.revalidate()
                        if !ok {
                            await MainActor.run {
                                licenseInfo = nil
                                LicenseService.logout()
                            }
                            await MainActor.run { statusChecked = true }
                            return
                        }
                        if let fresh = LicenseService.loadCached() {
                            await MainActor.run { licenseInfo = fresh }
                        }
                        let result = await AppStatusService.checkStatus(isPro: cached.isPro)
                        await MainActor.run {
                            statusResult = result
                            statusChecked = true
                        }
                    } else {
                        await MainActor.run { statusChecked = true }
                    }
                }
                .onReceive(
                    NotificationCenter.default.publisher(for: UIApplication.willTerminateNotification)
                ) { _ in
                    UninstallDetector.onWillTerminate()
                }
        }
    }

    @ViewBuilder
    private var contentView: some View {
        if !statusChecked {
            // Splash
            ZStack {
                Aurora.bg.ignoresSafeArea()
                RadialGradient(
                    colors: [Aurora.purple.opacity(0.20), .clear],
                    center: .center, startRadius: 0, endRadius: 300
                ).ignoresSafeArea()
                VStack(spacing: 16) {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(Aurora.purpleGlow)
                    Text("AIMLOCK HZZ")
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(Aurora.textSub)
                }
            }
        } else if case .blocked(let msg) = statusResult {
            BlockedView(message: msg)
        } else if let info = licenseInfo {
            GameSelectView(
                licenseInfo: info,
                onLogout: {
                    licenseInfo = nil
                    LicenseService.logout()
                }
            )
        } else {
            LoginView { info in
                licenseInfo = info
                Task {
                    let result = await AppStatusService.checkStatus(isPro: info.isPro)
                    await MainActor.run { statusResult = result }
                }
            }
        }
    }
}
