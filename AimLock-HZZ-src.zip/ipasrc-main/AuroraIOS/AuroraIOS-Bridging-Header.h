#ifndef AuroraIOS_Bridging_Header_h
#define AuroraIOS_Bridging_Header_h

// ── kexploit: OPA334/ICMPv6 kernel exploit chain (iOS 17.0–26.0.x) ─────────
#import "kexploit/kexploit_opa334.h"
#import "kexploit/krw.h"
#import "kexploit/kutils.h"
#import "kexploit/offsets.h"
#import "kexploit/vnode.h"
#import "kexploit/machine_info.h"
#import "kexploit/xpaci.h"

// ── kexploit: kfd / libkfd (iOS 15.0–16.7.x) ────────────────────────────────
#import "kexploit/kexploit_ios15/kexploit_ios15.h"
#import "kexploit/kexploit_ios15/sandbox_escape_ios15.h"

// ── exploit: sandbox escape + filesystem access mechanisms ──────────────────
#import "exploit/sandbox_escape.h"
#import "exploit/bad_query.h"
#import "exploit/MCMBridge.h"
#import "exploit/BadQueryManager.h"
#import "exploit/SandboxEscapeManager.h"
#import "exploit/ContainerManager.h"
#import "exploit/AppStatusChecker.h"
#import "exploit/AppEnumerator.h"
#import "exploit/apfs_own.h"

// ── kpf: kernel patchfinder (XPF) ───────────────────────────────────────────
#import "kpf/patchfinder.h"

#endif /* AuroraIOS_Bridging_Header_h */
