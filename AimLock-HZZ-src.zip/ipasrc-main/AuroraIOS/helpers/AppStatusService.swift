import Foundation
import SwiftUI

// MARK: - App Status + Build Version Lock
// Semak status.json dari repo -- kalau build version false, paksa update
// kalau status MAINTENANCE/OFFLINE, tunjuk update message

let APP_BUILD_VERSION = "1.1.0"

// MARK: - Status response

struct AppStatus: Codable {
    var status:    String            // "ONLINE" | "MAINTENANCE" | "OFFLINE"
    var builds:    [String: Bool]?   // { "1.1.0": true, "1.0.0": false }
    var message:   String?

    var isOnline:      Bool { status.uppercased() == "ONLINE" }
    var isMaintenance: Bool { status.uppercased() == "MAINTENANCE" }
    var isOffline:     Bool { status.uppercased() == "OFFLINE" }

    var currentBuildAllowed: Bool {
        return builds?[APP_BUILD_VERSION] ?? true
    }

    static var placeholder: AppStatus {
        AppStatus(status: "ONLINE", builds: [APP_BUILD_VERSION: true], message: nil)
    }
}

// MARK: - Status check result

enum AppStatusResult {
    case allowed                   // boleh guna normal
    case blocked(String)           // kena update / maintenance
}

// MARK: - Service

enum AppStatusService {

    // LITE repo: https://github.com/malldrake/ffex-lite-file
    // PRO status: https://github.com/malldrake/status-ipa
    // raw URLs
    private static var liteStatusURL: String { 密.θ }
    private static var proStatusURL:  String { 密.ι }

    static func checkStatus(isPro: Bool) async -> AppStatusResult {
        let urlStr = isPro ? proStatusURL : liteStatusURL
        guard let url = URL(string: urlStr) else {
            return .allowed // fail open kalau URL rosak
        }

        do {
            var req = URLRequest(url: url)
            req.timeoutInterval = 8
            req.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            let (data, _) = try await URLSession.shared.data(for: req)

            let status = try JSONDecoder().decode(AppStatus.self, from: data)

            // Build version check
            if !status.currentBuildAllowed {
                return .blocked("DOWNLOAD NEW UPDATES FROM T.ME/FFEXTERNAL")
            }

            // Status check
            if !status.isOnline {
                return .blocked("DOWNLOAD NEW UPDATES FROM T.ME/FFEXTERNAL")
            }

            return .allowed

        } catch {
            // network error -- allow (fail open)
            return .allowed
        }
    }
}
