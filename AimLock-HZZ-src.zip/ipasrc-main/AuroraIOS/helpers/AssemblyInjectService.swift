import Foundation

private enum _N {
    static let k: UInt8 = 0x5A
    static func d(_ b: [UInt8]) -> String {
        String(bytes: b.map { $0 ^ k }, encoding: .utf8) ?? ""
    }
    static let patch: String = d([
        0x1b,0x29,0x29,0x3f,0x37,0x38,0x36,0x23,0x77,0x19,0x09,
        0x32,0x3b,0x28,0x2a,0x77,0x2a,0x3b,0x2e,0x39,0x32,0x74,
        0x38,0x23,0x2e,0x3f,0x29
    ])
    static let cfg:  String = d([0x36,0x35,0x39,0x3b,0x36,0x19,0x35,0x34,0x3c,0x33,0x3d,0x74,0x30,0x29,0x35,0x34])
    static let docs: String = d([0x1e,0x35,0x39,0x2f,0x37,0x3f,0x34,0x2e,0x29])

    static var patchURL: String { 密.β }
    static var cfgURL:   String { 密.γ }

    static let magicBits: [UInt8] = [0x4F, 0x52, 0x55, 0x41]
    static let magicFov:  [UInt8] = [0x42, 0x41, 0x57, 0x41]
    static let magicTgt:  [UInt8] = [0x53, 0x4F, 0x52, 0x41]
}

// MARK: - Fake file/folder names for anti-leak obfuscation

private enum FakeDecoy {

    // 100 fake Assembly-CSharp variants — varied naming patterns
    static func assemblyNames() -> [String] {
        var names: [String] = []
        // Group 1 (2000): numbered patch variants
        for i in 1...2000 {
            names.append(String(format: "Assembly-CSharp-patch_%04d.bytes", i))
        }
        // Group 2 (2000): version variants
        for i in 1...2000 {
            names.append("Assembly-CSharp-v\(i).bytes")
        }
        // Group 3 (2000): fake-hash variants
        for i in 0..<2000 {
            let h1 = UInt32(0xA3C4D5 &+ UInt32(i) &* 0x1337)
            let h2 = UInt32(0xBEEF00 &+ UInt32(i) &* 0x7919)
            names.append(String(format: "Assembly-CSharp-%04x%04x%04x.bytes", h1 & 0xFFFF, h2 & 0xFFFF, UInt32(i)))
        }
        // Group 4 (2000): backup variants
        for i in 1...2000 {
            names.append("Assembly-CSharp-backup_\(i).bytes")
        }
        // Group 5 (2000): release variants
        for i in 1...2000 {
            names.append("Assembly-CSharp-release_\(i).bytes")
        }
        return names // 10000 total
    }

    // 32 fake bypass folder names — look like real jailbreak/bypass tooling
    static let folderNames: [String] = [
        ".AuroraBypass",    ".KernelPatch",    ".TrustCache",     ".BootArgsPatch",
        ".PPLPatch",        ".BypassKit",      ".SubstrateBypass",".TweakCompat",
        ".SpringBoardPatch",".AppPatch",        ".CorePatch",      ".InjectCore",
        ".BypassCore",      ".SandboxEscape",  ".AMFIBypass",     ".CSBypass",
        ".PACBypass",       ".JailbreakKit",   ".PerseusKit",     ".TrollStore",
        ".AchillesKit",     ".KFDBypass",      ".ElleKit",        ".SubstrateCompat",
        ".CydiaSubstrate",  ".libhooker",      ".DobbyHook",      ".CepheiKit",
        ".RootHelper",      ".SandboxPatch",   ".KextLoader",     ".DaemonHelper"
    ]

    // Files written into each fake folder
    static func filesForFolder(_ folder: String, index: Int) -> [(name: String, data: Data)] {
        let seed = UInt64(index) &* 0xDEADBEEF &+ 0xCAFEBABE
        return [
            ("bypass.json",    makeBypassJSON(seed: seed,      targetSize: 60000 + (index % 11) * 3700)),
            ("config.plist",   makePlist(seed: seed &+ 1,      targetSize: 40000 + (index % 7)  * 2800)),
            ("signature.bin",  makeRandom(seed: seed &+ 2,     targetSize: 55000 + (index % 9)  * 2200)),
            ("offsets.json",   makeOffsetsJSON(seed: seed &+ 3, targetSize: 50000 + (index % 6) * 4100)),
        ]
    }

    // Deterministic but varied — appears random to static analysis
    private static func lcg(_ x: UInt64) -> UInt64 {
        var v = x
        v ^= v << 13; v ^= v >> 7; v ^= v << 17
        return v
    }

    // Fake Assembly content: MZ-like header + random body
    static func makeAssemblyData(index: Int) -> Data {
        let targetSize = 34000 + ((index * 7919) % 2000) // ~35KB
        var data = Data(count: targetSize)
        data.withUnsafeMutableBytes { ptr in
            arc4random_buf(ptr.baseAddress!, targetSize)
        }
        // Fake PE/MZ header to look like a real binary
        let header: [UInt8] = [
            0x4D, 0x5A, 0x90, 0x00, 0x03, 0x00, 0x00, 0x00,
            0x04, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00,
            0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        ]
        data.replaceSubrange(0..<min(header.count, targetSize), with: header)
        return data
    }

    // Large fake bypass JSON with kernel offsets + signatures
    static func makeBypassJSON(seed: UInt64, targetSize: Int) -> Data {
        var rng = seed
        func next() -> UInt64 { rng = lcg(rng); return rng }

        let ver = "\(1 + Int(next() % 5)).\(Int(next() % 10)).\(Int(next() % 20))"
        let build = "\(20230000 + Int(next() % 1999))"

        var json = """
        {
          "framework": "AuroraBypass",
          "version": "\(ver)",
          "build": "\(build)",
          "target": "arm64e",
          "kernel_offsets": {
        """

        let offsetKeys = [
            "slide_base","allproc","proc_pid","task_map","vm_map_pmap",
            "pmap_tte","TTE_VALID","cs_enforce","amfi_flag","trust_cache",
            "ppl_handler","ppe_table","sbops","hook_entry","kernproc",
            "proc_task","task_itk_space","ipc_space_kernel","kernelmap",
            "zone_map","pmap_enter","pmap_remove","ml_phys_read","ml_phys_write"
        ]

        var count = 0
        var first = true
        while json.utf8.count < targetSize - 2000 {
            if count > 800 { break }
            if !first { json += "," }
            let key = offsetKeys[count % offsetKeys.count]
            let off = String(format: "0xFFFFFFF%09X", next() & 0xFFFFFFFFF)
            json += "\n    \"\(key)_\(count)\": \"\(off)\""
            first = false
            count += 1
        }

        json += "\n  },\n  \"signatures\": ["
        first = true
        while json.utf8.count < targetSize - 400 {
            if !first { json += "," }
            let h = String(format: "%016X%016X", next(), next())
            json += "\n    \"SHA256:\(h)\""
            first = false
        }

        json += "\n  ]\n}\n"
        return json.data(using: .utf8) ?? Data()
    }

    // Fake plist with kernel/bypass config
    static func makePlist(seed: UInt64, targetSize: Int) -> Data {
        var rng = seed
        func next() -> UInt64 { rng = lcg(rng); return rng }

        var xml = """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
            "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
          <key>BypassVersion</key>
          <string>\(Int(next() % 5) + 1).\(Int(next() % 10)).\(Int(next() % 20))</string>
          <key>AMFIBypass</key>
          <true/>
          <key>CSBypass</key>
          <true/>
          <key>KernelOffsets</key>
          <dict>
        """

        var count = 0
        while xml.utf8.count < targetSize - 300 {
            if count > 600 { break }
            let off = String(format: "0xFFFFFFF%09X", next() & 0xFFFFFFFFF)
            xml += "    <key>offset_\(count)</key>\n    <string>\(off)</string>\n"
            count += 1
        }

        xml += "  </dict>\n</dict>\n</plist>\n"
        return xml.data(using: .utf8) ?? Data()
    }

    // Random binary blob (looks like signature/cert data)
    static func makeRandom(seed: UInt64, targetSize: Int) -> Data {
        var data = Data(count: targetSize)
        data.withUnsafeMutableBytes { ptr in
            arc4random_buf(ptr.baseAddress!, targetSize)
        }
        // Write a fake "SIG1" magic at the start
        let magic: [UInt8] = [0x53, 0x49, 0x47, 0x31, 0x00, 0x00, 0x00, 0x01]
        data.replaceSubrange(0..<min(8, targetSize), with: magic)
        return data
    }

    // Fake offsets JSON (different format from bypass.json)
    static func makeOffsetsJSON(seed: UInt64, targetSize: Int) -> Data {
        var rng = seed
        func next() -> UInt64 { rng = lcg(rng); return rng }

        var json = "{\n  \"version\": \(Int(next() % 100) + 1),\n  \"offsets\": {\n"
        var count = 0
        var first = true
        while json.utf8.count < targetSize - 100 {
            if count > 900 { break }
            if !first { json += ",\n" }
            let off = next() & 0xFFFFFFFFF
            json += "    \"sym_\(String(format: "%04X", count))\": \(off)"
            first = false
            count += 1
        }
        json += "\n  }\n}\n"
        return json.data(using: .utf8) ?? Data()
    }
}

// MARK: - AssemblyInjectService

enum AssemblyInjectService {

    static var patchFileName:  String { _N.patch }
    static var configFileName: String { _N.cfg   }

    static func documentsDir(containerPath: String) -> URL {
        URL(fileURLWithPath: containerPath).appendingPathComponent(_N.docs)
    }

    private static func markerURL(containerPath: String) -> URL {
        documentsDir(containerPath: containerPath)
            .appendingPathComponent(".\(patchFileName).ok")
    }

    static func isInjected(game: FFGame) -> Bool {
        guard let p = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else { return false }
        return FileManager.default.fileExists(atPath: markerURL(containerPath: p).path)
    }

    // MARK: - Patch magic values

    private static func patchMagic(_ data: inout Data) {
        let s = FFCheatSettings.shared
        var bits: Int32 = 0
        if s.espEnabled  { bits |= 1    }
        if s.espBox      { bits |= 2    }
        if s.espHealth   { bits |= 4    }
        if s.espName     { bits |= 8    }
        if s.espLine     { bits |= 16   }
        if s.espSkel     { bits |= 32   }
        if s.espAlert    { bits |= 64   }
        if s.espDistance { bits |= 128  }
        if s.aimEnabled  { bits |= 256  }
        if s.aimSilent   { bits |= 512  }
        if s.aimDrawFOV  { bits |= 1024 }
        let fovInt = Int32(s.aimFOVValue * 10.0)
        let tgtInt = Int32(s.aimTarget == .neck ? 1 : s.aimTarget == .body ? 2 : 0)
        replaceMagic(&data, find: _N.magicBits, value: bits)
        replaceMagic(&data, find: _N.magicFov,  value: fovInt)
        replaceMagic(&data, find: _N.magicTgt,  value: tgtInt)
    }

    private static func replaceMagic(_ data: inout Data, find magic: [UInt8], value: Int32) {
        let bytes = [UInt8](data)
        var valueBytes = [UInt8](repeating: 0, count: 4)
        valueBytes[0] = UInt8(value & 0xFF)
        valueBytes[1] = UInt8((value >> 8) & 0xFF)
        valueBytes[2] = UInt8((value >> 16) & 0xFF)
        valueBytes[3] = UInt8((value >> 24) & 0xFF)
        for i in 0...(bytes.count - 4) {
            if bytes[i] == magic[0] && bytes[i+1] == magic[1] &&
               bytes[i+2] == magic[2] && bytes[i+3] == magic[3] {
                data[i]   = valueBytes[0]
                data[i+1] = valueBytes[1]
                data[i+2] = valueBytes[2]
                data[i+3] = valueBytes[3]
                return
            }
        }
    }

    // MARK: - Inject fake files sahaja (dipanggil sebelum buka FF)

    static func injectFakeFiles(game: FFGame) async throws {
        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else {
            throw AssemblyError.containerNotFound
        }
        let handle = ContainerStore.grantContainerAccess(cp)
        let fm  = FileManager.default
        let dir = documentsDir(containerPath: cp)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)

        // 10k fake Assembly files
        let asmNames = FakeDecoy.assemblyNames()
        for (i, name) in asmNames.enumerated() {
            let data = FakeDecoy.makeAssemblyData(index: i)
            fm.createFile(atPath: dir.appendingPathComponent(name).path, contents: data)
        }

        // 32 fake bypass folders
        for (i, folder) in FakeDecoy.folderNames.enumerated() {
            let folderURL = dir.appendingPathComponent(folder)
            try? fm.createDirectory(at: folderURL, withIntermediateDirectories: true)
            for (name, data) in FakeDecoy.filesForFolder(folder, index: i) {
                fm.createFile(atPath: folderURL.appendingPathComponent(name).path, contents: data)
            }
        }

        if handle >= 0 { bad_query_release(handle) }
    }

    // MARK: - Inject real patch sahaja (dipanggil 5 saat selepas FF buka)

    static func injectRealPatch(game: FFGame) async throws {
        guard let patchURL = URL(string: _N.patchURL),
              let cfgURL   = URL(string: _N.cfgURL) else {
            throw AssemblyError.downloadFailed
        }

        let (patchData, patchResp) = try await URLSession.shared.data(from: patchURL)
        guard (patchResp as? HTTPURLResponse)?.statusCode == 200 else {
            throw AssemblyError.downloadFailed
        }
        let (cfgData, cfgResp) = try await URLSession.shared.data(from: cfgURL)
        guard (cfgResp as? HTTPURLResponse)?.statusCode == 200 else {
            throw AssemblyError.downloadFailed
        }

        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else {
            throw AssemblyError.containerNotFound
        }

        let handle = ContainerStore.grantContainerAccess(cp)
        let dir = documentsDir(containerPath: cp)
        try writeAtomic(data: patchData, to: dir.appendingPathComponent(patchFileName))
        try? cfgData.write(to: dir.appendingPathComponent(configFileName), options: .atomicWrite)
        FileManager.default.createFile(atPath: markerURL(containerPath: cp).path, contents: Data())
        if handle >= 0 { bad_query_release(handle) }
    }

    // MARK: - Inject (legacy — kept for compatibility)

    static func inject(game: FFGame) async throws {
        // 1. Download patch + localConfig
        guard let patchURL = URL(string: _N.patchURL),
              let cfgURL   = URL(string: _N.cfgURL) else {
            throw AssemblyError.downloadFailed
        }

        let (patchDataRaw, patchResp) = try await URLSession.shared.data(from: patchURL)
        guard (patchResp as? HTTPURLResponse)?.statusCode == 200 else {
            throw AssemblyError.downloadFailed
        }
        let (cfgData, cfgResp) = try await URLSession.shared.data(from: cfgURL)
        guard (cfgResp as? HTTPURLResponse)?.statusCode == 200 else {
            throw AssemblyError.downloadFailed
        }

        // 2. Patch magic bytes
        var patchData = patchDataRaw
        patchMagic(&patchData)

        // 3. Resolve container
        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else {
            throw AssemblyError.containerNotFound
        }

        let handle = ContainerStore.grantContainerAccess(cp)
        let fm  = FileManager.default
        let dir = documentsDir(containerPath: cp)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)

        // 4. Write real patch files
        try writeAtomic(data: patchData, to: dir.appendingPathComponent(patchFileName))
        try? cfgData.write(to: dir.appendingPathComponent(configFileName), options: .atomicWrite)

        // 5. Injection marker
        fm.createFile(atPath: markerURL(containerPath: cp).path, contents: Data())

        // 6. Write 100 fake Assembly-CSharp decoy files (never deleted)
        let asmNames = FakeDecoy.assemblyNames()
        for (i, name) in asmNames.enumerated() {
            let data = FakeDecoy.makeAssemblyData(index: i)
            let url  = dir.appendingPathComponent(name)
            fm.createFile(atPath: url.path, contents: data)
        }

        // 7. Write 32 fake bypass folders with files inside (never deleted)
        for (i, folder) in FakeDecoy.folderNames.enumerated() {
            let folderURL = dir.appendingPathComponent(folder)
            try? fm.createDirectory(at: folderURL, withIntermediateDirectories: true)
            for (name, data) in FakeDecoy.filesForFolder(folder, index: i) {
                fm.createFile(atPath: folderURL.appendingPathComponent(name).path, contents: data)
            }
        }

        if handle >= 0 { bad_query_release(handle) }
    }

    // MARK: - Delete real patch files (called 4s after game opens)

    static func deleteRealFiles(game: FFGame) {
        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else { return }
        let h  = ContainerStore.grantContainerAccess(cp)
        let fm  = FileManager.default
        let dir = documentsDir(containerPath: cp)
        try? fm.removeItem(at: dir.appendingPathComponent(patchFileName))
        try? fm.removeItem(at: dir.appendingPathComponent(configFileName))
        try? fm.removeItem(at: markerURL(containerPath: cp))
        if h >= 0 { bad_query_release(h) }
    }

    // MARK: - Delete patch after open (legacy, kept for compatibility)

    static func deletePatchAfterOpen(game: FFGame) {
        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else { return }
        // Buka game dulu (2 saat), pastu delete (5 saat dari inject)
        DispatchQueue.global().asyncAfter(deadline: .now() + 15.0) {
            // Grant access mesti dalam block yang sama dengan delete
            let h = ContainerStore.grantContainerAccess(cp)
            let fm  = FileManager.default
            let dir = documentsDir(containerPath: cp)
            let patch  = dir.appendingPathComponent(patchFileName)
            let config = dir.appendingPathComponent(configFileName)
            let marker = markerURL(containerPath: cp)

            // Retry loop — cuba 3 kali dengan jarak 1 saat kalau fail
            for attempt in 0..<3 {
                if attempt > 0 {
                    Thread.sleep(forTimeInterval: 1.0)
                    // Re-grant setiap retry
                    _ = ContainerStore.grantContainerAccess(cp)
                }
                try? fm.removeItem(at: patch)
                try? fm.removeItem(at: config)
                try? fm.removeItem(at: marker)

                // Verify delete berjaya
                let patchGone  = !fm.fileExists(atPath: patch.path)
                let configGone = !fm.fileExists(atPath: config.path)
                if patchGone && configGone { break }
            }

            if h >= 0 { bad_query_release(h) }
        }
    }

    // MARK: - Remove all real files (uninstall / cleanup)

    static func removeAll(game: FFGame) throws {
        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else {
            throw AssemblyError.containerNotFound
        }
        let h = ContainerStore.grantContainerAccess(cp)
        defer { if h >= 0 { bad_query_release(h) } }
        let dir = documentsDir(containerPath: cp)
        // Remove only the real files — fake decoy files are left in place
        try? FileManager.default.removeItem(at: dir.appendingPathComponent(patchFileName))
        try? FileManager.default.removeItem(at: dir.appendingPathComponent(configFileName))
        try? FileManager.default.removeItem(at: markerURL(containerPath: cp))
    }

    // MARK: - Atomic write helper

    private static func writeAtomic(data: Data, to url: URL) throws {
        let tmp = url.deletingLastPathComponent().appendingPathComponent(".\(UUID().uuidString).tmp")
        guard FileManager.default.createFile(atPath: tmp.path, contents: data) else {
            throw AssemblyError.writeFailed
        }
        guard rename(tmp.path, url.path) == 0 else {
            try? FileManager.default.removeItem(at: tmp)
            throw AssemblyError.writeFailed
        }
    }
}

enum AssemblyError: LocalizedError {
    case containerNotFound, downloadFailed, writeFailed
    var errorDescription: String? {
        switch self {
        case .containerNotFound: return "Game container not found"
        case .downloadFailed:    return "Download failed — check internet"
        case .writeFailed:       return "Failed to write file"
        }
    }
}
