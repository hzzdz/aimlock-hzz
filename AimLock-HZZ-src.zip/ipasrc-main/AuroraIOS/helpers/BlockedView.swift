import SwiftUI

// MARK: - Blocked / Maintenance View
// Tunjuk bila status MAINTENANCE/OFFLINE atau build version blocked

struct BlockedView: View {
    let message: String

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 24) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 48))
                    .foregroundStyle(Color(red: 1, green: 0.6, blue: 0))

                Text(message)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)

                Link("@FFEXTERNAL", destination: URL(string: "https://t.me/ffexternal")!)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(Color(red: 0.04, green: 0.52, blue: 1.0))
            }
        }
    }
}
