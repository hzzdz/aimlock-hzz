import Foundation
import UIKit

// MARK: - Device Identification

enum DeviceID {

    static var hwid: String {
        let key = "x.dev.hwid"
        if let v = UserDefaults.standard.string(forKey: key) { return v }
        let id = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        UserDefaults.standard.set(id, forKey: key)
        return id
    }

    static var iOSVersion: String {
        UIDevice.current.systemVersion
    }

    static var iPhoneModel: String {
        var s = utsname(); uname(&s)
        let id = withUnsafeBytes(of: &s.machine) {
            $0.filter { $0 != 0 }.map { Character(UnicodeScalar($0)) }
        }
        let model = String(id)
        let map: [String: String] = [
            "iPhone12,1":"iPhone 11","iPhone12,3":"iPhone 11 Pro","iPhone12,5":"iPhone 11 Pro Max",
            "iPhone13,1":"iPhone 12 mini","iPhone13,2":"iPhone 12","iPhone13,3":"iPhone 12 Pro",
            "iPhone13,4":"iPhone 12 Pro Max","iPhone14,4":"iPhone 13 mini","iPhone14,5":"iPhone 13",
            "iPhone14,2":"iPhone 13 Pro","iPhone14,3":"iPhone 13 Pro Max","iPhone14,7":"iPhone 14",
            "iPhone14,8":"iPhone 14 Plus","iPhone15,2":"iPhone 14 Pro","iPhone15,3":"iPhone 14 Pro Max",
            "iPhone15,4":"iPhone 15","iPhone15,5":"iPhone 15 Plus","iPhone16,1":"iPhone 15 Pro",
            "iPhone16,2":"iPhone 15 Pro Max","iPhone17,1":"iPhone 16 Pro","iPhone17,2":"iPhone 16 Pro Max",
            "iPhone17,3":"iPhone 16","iPhone17,4":"iPhone 16 Plus",
        ]
        return map[model] ?? model
    }
}
