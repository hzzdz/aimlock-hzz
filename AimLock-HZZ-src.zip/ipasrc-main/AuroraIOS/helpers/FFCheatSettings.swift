import Foundation
import SwiftUI

// MARK: - Cheat Settings (shared state, persisted via UserDefaults)

final class FFCheatSettings: ObservableObject {

    static let shared = FFCheatSettings()

    // MARK: - ESP
    @Published var espEnabled:     Bool { didSet { save() } }
    @Published var espLine:        Bool { didSet { save() } }
    @Published var espBox:         Bool { didSet { save() } }
    @Published var espHealth:      Bool { didSet { save() } }
    @Published var espDistance:    Bool { didSet { save() } }
    @Published var espName:        Bool { didSet { save() } }
    @Published var espSkel:        Bool { didSet { save() } }
    @Published var espAlert:       Bool { didSet { save() } }

    // MARK: - AIM
    @Published var aimEnabled:  Bool      { didSet { save() } }
    @Published var aimSilent:   Bool      { didSet { save() } }
    @Published var aimTarget:   AimTarget { didSet { save() } }
    @Published var aimDrawFOV:  Bool      { didSet { save() } }
    @Published var aimFOVValue: Double    { didSet { save() } }

    private enum K {
        static let espEnabled  = "a.esp.en"
        static let espLine     = "a.esp.ln"
        static let espBox      = "a.esp.bx"
        static let espHealth   = "a.esp.hp"
        static let espDistance = "a.esp.ds"
        static let espName     = "a.esp.nm"
        static let espSkel     = "a.esp.sk"
        static let espAlert    = "a.esp.al"
        static let aimEnabled  = "a.aim.en"
        static let aimSilent   = "a.aim.sl"
        static let aimTarget   = "a.aim.tg"
        static let aimDrawFOV  = "a.aim.df"
        static let aimFOVValue = "a.aim.fv"
    }

    private init() {
        let d = UserDefaults.standard
        espEnabled  = d.bool(forKey: K.espEnabled)
        espLine     = d.bool(forKey: K.espLine)
        espBox      = d.bool(forKey: K.espBox)
        espHealth   = d.bool(forKey: K.espHealth)
        espDistance = d.bool(forKey: K.espDistance)
        espName     = d.bool(forKey: K.espName)
        espSkel     = d.bool(forKey: K.espSkel)
        espAlert    = d.bool(forKey: K.espAlert)
        aimEnabled  = d.bool(forKey: K.aimEnabled)
        aimSilent   = d.bool(forKey: K.aimSilent)
        aimTarget   = AimTarget(rawValue: d.string(forKey: K.aimTarget) ?? "") ?? .head
        aimDrawFOV  = d.bool(forKey: K.aimDrawFOV)
        aimFOVValue = d.object(forKey: K.aimFOVValue) != nil ? d.double(forKey: K.aimFOVValue) : 120.0
    }

    private func save() {
        let d = UserDefaults.standard
        d.set(espEnabled,  forKey: K.espEnabled)
        d.set(espLine,     forKey: K.espLine)
        d.set(espBox,      forKey: K.espBox)
        d.set(espHealth,   forKey: K.espHealth)
        d.set(espDistance, forKey: K.espDistance)
        d.set(espName,     forKey: K.espName)
        d.set(espSkel,     forKey: K.espSkel)
        d.set(espAlert,    forKey: K.espAlert)
        d.set(aimEnabled,  forKey: K.aimEnabled)
        d.set(aimSilent,   forKey: K.aimSilent)
        d.set(aimTarget.rawValue, forKey: K.aimTarget)
        d.set(aimDrawFOV,  forKey: K.aimDrawFOV)
        d.set(aimFOVValue, forKey: K.aimFOVValue)
    }

    func resetAll() {
        espEnabled = false; espLine = false; espBox = false
        espHealth = false; espDistance = false; espName = false
        espSkel = false; espAlert = false
        aimEnabled = false; aimSilent = false
        aimTarget = .head; aimDrawFOV = false; aimFOVValue = 120.0
    }
}

// MARK: - Enums

enum AimTarget: String, CaseIterable, Identifiable {
    case head  = "head"
    case neck  = "neck"
    case body  = "body"
    var id: String { rawValue }
    var label: String {
        switch self {
        case .head:  return "Head"
        case .neck:  return "Neck"
        case .body:  return "Body"
        }
    }
}
