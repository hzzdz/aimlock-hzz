import Foundation
import UIKit

// MARK: - License Info

struct LicenseInfo: Codable {
    var key:          String
    var licenseType:  String   // "vip" = lite, "pro" = pro
    var expiryDate:   Date?
    var isGlobal:     Bool
    var hwid:         String?

    var isPro: Bool { licenseType.lowercased() == "pro" }
}

// MARK: - LicenseService

enum LicenseError: LocalizedError {
    case invalid(String)
    case network(String)

    var errorDescription: String? {
        switch self {
        case .invalid(let m): return m
        case .network(let m): return "Network error: \(m)"
        }
    }
}

private enum _X {
    static let k: UInt8 = 0x5A
    static func d(_ b: [UInt8]) -> String {
        String(bytes: b.map { $0 ^ k }, encoding: .utf8) ?? ""
    }
    // "https://ffex-xi.vercel.app/api/licenses/validate"
    static let url: String = d([
        0x32,0x2e,0x2e,0x2a,0x29,0x60,0x75,0x75,0x3c,0x3c,0x3f,0x38,0x79,0x38,0x33,
        0x74,0x27,0x3f,0x28,0x39,0x3f,0x36,0x74,0x3b,0x2a,0x2a,0x75,0x3b,0x2a,0x33,
        0x75,0x36,0x33,0x39,0x3f,0x34,0x29,0x3f,0x29,0x75,0x27,0x3b,0x36,0x33,0x3f,
        0x2e,0x3f,0x75,0x28,0x3b,0x36,0x33,0x3d,0x3b,0x2e,0x3f
    ])
    static var validateURL: String { 密.α }
}

enum LicenseService {

    // MARK: - Validate

    static func validate(key: String) async throws -> LicenseInfo {
        let hwid = DeviceID.hwid

        guard let url = URL(string: _X.validateURL) else {
            throw LicenseError.network("Bad URL")
        }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 15
        req.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData

        let body: [String: String] = ["key": key.uppercased(), "hwid": hwid]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)
        let code = (response as? HTTPURLResponse)?.statusCode ?? 0

        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw LicenseError.network("Invalid response")
        }

        let valid = json["valid"] as? Bool ?? false
        if !valid {
            let msg = json["error"] as? String ?? "Invalid key"
            throw LicenseError.invalid(msg)
        }

        // parse response
        var info = LicenseInfo(
            key:         key.uppercased(),
            licenseType: json["license_type"] as? String ?? "vip",
            expiryDate:  nil,
            isGlobal:    json["is_global"] as? Bool ?? false,
            hwid:        json["hwid"] as? String
        )

        if let exp = json["expires_at"] as? String {
            let fmt = ISO8601DateFormatter()
            fmt.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            info.expiryDate = fmt.date(from: exp) ?? ISO8601DateFormatter().date(from: exp)
        }

        // persist
        persist(info)
        return info
    }

    // MARK: - Persist / Load

    private static let _kInfo = "x.lic.info"
    private static let _kTime = "x.lic.ts"

    static func persist(_ info: LicenseInfo) {
        if let d = try? JSONEncoder().encode(info) {
            UserDefaults.standard.set(d, forKey: _kInfo)
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: _kTime)
        }
    }

    static func loadCached() -> LicenseInfo? {
        guard let d = UserDefaults.standard.data(forKey: _kInfo),
              let info = try? JSONDecoder().decode(LicenseInfo.self, from: d) else {
            return nil
        }
        return info
    }

    static func logout() {
        UserDefaults.standard.removeObject(forKey: _kInfo)
        UserDefaults.standard.removeObject(forKey: _kTime)
    }

    // re-validate setiap open app
    static func revalidate() async -> Bool {
        guard let cached = loadCached() else { return false }
        do {
            let fresh = try await validate(key: cached.key)
            persist(fresh)
            return true
        } catch {
            return false
        }
    }

    // MARK: - Helpers

    static func maskedKey(_ key: String) -> String {
        let parts = key.split(separator: "-")
        guard parts.count >= 4 else { return String(key.prefix(12)) + "***" }
        let prefix = parts.prefix(2).joined(separator: "-")
        let last = String(parts.last ?? "****")
        let masked = String(repeating: "*", count: max(0, last.count - 3)) + last.suffix(3)
        return "\(prefix)-***-\(masked)"
    }

    static func countdownString(from date: Date) -> String {
        let diff = date.timeIntervalSinceNow
        if diff <= 0 { return "Expired" }
        let h = Int(diff / 3600)
        let m = Int((diff.truncatingRemainder(dividingBy: 3600)) / 60)
        if h > 48 { return "\(h / 24)d \(h % 24)h" }
        return "\(h)h \(m)m"
    }
}
