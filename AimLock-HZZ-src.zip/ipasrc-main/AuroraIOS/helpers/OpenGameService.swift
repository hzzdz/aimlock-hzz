import UIKit

enum OpenGameService {

    static func openGame(_ game: FFGame, afterDelete: Bool = true) {
        if afterDelete {
            AssemblyInjectService.deletePatchAfterOpen(game: game)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            let scheme: String
            switch game {
            case .freeFire:    scheme = "freefireth://"
            case .freefireMax: scheme = "freefiremax://"
            }
            guard let url = URL(string: scheme) else { return }
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }
}
