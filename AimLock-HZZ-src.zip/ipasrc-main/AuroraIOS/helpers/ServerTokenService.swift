import Foundation

// MARK: - Server Token Protection
// Buat .ffex-server file yang encrypted dengan HWID + key info
// File ini wajib ada untuk patch berfungsi
// Orang lain leak patch.dat -- tak guna sebab takde .ffex-server dengan HWID mereka

private enum _K {
    static let v: [UInt8] = [
        0x2A,0xCB,0xE3,0x9C,0xDA,0x13,0xA0,0x23,
        0x13,0x1F,0x14,0x3B,0x5E,0x05,0x71,0xAA,
        0x51,0x6F,0xB8,0xB2,0xA4,0x43,0x4E,0xDA,
        0xC5,0xE1,0x74,0x33,0x7F,0xEE,0xD8,0x7B
    ]
    static func enc(_ data: Data) -> Data {
        let kl = v.count
        let bytes = [UInt8](data)
        return Data(bytes.enumerated().map { i, b in b ^ v[i % kl] })
    }
    static func dec(_ data: Data) -> Data { enc(data) } // XOR symmetric
}

struct ServerTokenPayload: Codable {
    var hwid:        String
    var key:         String
    var licenseType: String
    var timestamp:   Double
    var deviceModel: String
    var iosVersion:  String
}

enum ServerTokenService {

    // ".ffex-server" -- hidden file, nama obfuscated
    private static let tokenFileName = ".ffex-server"

    // MARK: - Write token ke game Documents/

    static func writeToken(
        for game: FFGame,
        key: String,
        licenseType: String
    ) {
        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else {
            return
        }
        let handle = ContainerStore.grantContainerAccess(cp)
        defer { if handle >= 0 { bad_query_release(handle) } }

        let dir = URL(fileURLWithPath: cp).appendingPathComponent("Documents")
        let tokenURL = dir.appendingPathComponent(tokenFileName)

        let payload = ServerTokenPayload(
            hwid:        DeviceID.hwid,
            key:         key,
            licenseType: licenseType,
            timestamp:   Date().timeIntervalSince1970,
            deviceModel: DeviceID.iPhoneModel,
            iosVersion:  DeviceID.iOSVersion
        )

        guard let raw = try? JSONEncoder().encode(payload) else { return }
        let encrypted = _K.enc(raw)
        try? encrypted.write(to: tokenURL, options: .atomicWrite)
    }

    // MARK: - Delete token (sama masa dengan patch delete)

    static func deleteToken(for game: FFGame) {
        guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else {
            return
        }
        let handle = ContainerStore.grantContainerAccess(cp)
        defer { if handle >= 0 { bad_query_release(handle) } }

        let tokenURL = URL(fileURLWithPath: cp)
            .appendingPathComponent("Documents")
            .appendingPathComponent(tokenFileName)
        try? FileManager.default.removeItem(at: tokenURL)
    }

    // MARK: - Delete semua (uninstall detection)

    static func deleteAllTokens() {
        for game in FFGame.allCases {
            deleteToken(for: game)
        }
    }
}
