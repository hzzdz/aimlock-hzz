import Foundation

enum ExploitSupportPolicy {

    // Verified ranges
    static let verifiedIOS15Range = "15.0–15.8.8"   // kfd / puaf_landa
    static let verifiedIOS16Range = "16.0–16.7.x"   // kfd / puaf_landa
    static let verifiedIOS17Range = "17.0–17.7.x"   // kexploit_opa334
    static let verifiedIOS18Range = "18.0–18.7.1"   // kexploit_opa334
    static let verifiedIOS26Range = "26.0–26.6.1"   // kexploit_opa334 (Mechanism B) or bad_query (D)
    // iOS 26.1+ Mechanism A: MCM direct — no kernel exploit needed

    static let verifiedIOS27Builds: [(beta: Int, publicBeta: Int?, build: String)] = [
        (1, nil, "24A5355q"),
        (2, nil, "24A5370h"),
        (3, 1,   "24A5380h"),
        (4, 2,   "24A5390f"),
    ]

    static func iOS27BetaNumber(for build: String) -> Int? {
        verifiedIOS27Builds.first { $0.build == build }?.beta
    }

    static func iOS27PublicBetaNumber(for build: String) -> Int? {
        verifiedIOS27Builds.first { $0.build == build }?.publicBeta
    }

    static func supportsKernelExploit(major: Int, minor: Int, patch: Int) -> Bool {
        guard minor >= 0, patch >= 0 else { return false }

        // iOS 15.x — kfd / puaf_landa (15.0–15.8.8)
        if major == 15 { return minor <= 8 }

        // iOS 16.x — kfd / puaf_landa (puaf_landa patched iOS 17.0 only; safe on all 16.x)
        if major == 16 { return minor <= 7 }

        // iOS 17.x — kexploit_opa334
        if major == 17 { return minor <= 7 }

        // iOS 18.x — kexploit_opa334
        if major == 18 { return minor < 7 || (minor == 7 && patch <= 1) }

        return false
    }

    static func isSupported(major: Int, minor: Int, patch: Int, build: String) -> Bool {
        if supportsKernelExploit(major: major, minor: minor, patch: patch) { return true }

        // iOS 26.0–26.6.1 — Mechanism B (opa334) or D (bad_query)
        if major == 26 {
            guard minor >= 0, patch >= 0 else { return false }
            return minor < 6 || (minor == 6 && patch <= 1)
        }

        // iOS 26.1+ — Mechanism A (MCM direct), supported but no kernel exploit
        if major == 26 && (minor > 1 || (minor == 1 && patch >= 0)) { return true }

        // iOS 27 beta
        guard major == 27, minor == 0, patch == 0 else { return false }
        return iOS27BetaNumber(for: build) != nil
    }
}
