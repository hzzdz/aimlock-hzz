import Foundation
import UIKit

// MARK: - Uninstall / Delete Detection
// Bila IPA dibuang, AppDelegate.applicationWillTerminate dipanggil
// Kita pakai KeychainService untuk detect fresh install vs restart
// Kalau fresh install (keychain kosong tapi UserDefaults ada) = reinstall = clear semua

enum UninstallDetector {

    private static let keychainKey = "x.ffex.installed"

    static func setup() {
        let wasInstalled = keychainGet(key: keychainKey) != nil
        if !wasInstalled {
            // Fresh install -- clear semua game files
            clearAllCheatFiles()
            // Mark sebagai installed
            keychainSet(key: keychainKey, value: "1")
        }
    }

    static func onWillTerminate() {
        // Bila app akan terminate -- pastikan state clean
        // Nota: kalau user delete app, system tak panggil willTerminate
        // tapi Keychain kekal -- detect next install
    }

    static func onUninstall() {
        // Delete semua files bila detect uninstall
        clearAllCheatFiles()
        keychainDelete(key: keychainKey)
    }

    private static func clearAllCheatFiles() {
        for game in FFGame.allCases {
            guard let cp = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) else {
                continue
            }
            let handle = ContainerStore.grantContainerAccess(cp)
            defer { if handle >= 0 { bad_query_release(handle) } }

            try? AssemblyInjectService.removeAll(game: game)
            ServerTokenService.deleteToken(for: game)
        }
    }

    // MARK: - Keychain helpers

    private static func keychainGet(key: String) -> String? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess,
              let d = result as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }

    private static func keychainSet(key: String, value: String) {
        let data = Data(value.utf8)
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key,
            kSecValueData: data,
            kSecAttrAccessible: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }

    private static func keychainDelete(key: String) {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key
        ]
        SecItemDelete(query as CFDictionary)
    }
}
