import SwiftUI
import UIKit
import SafariServices

// MARK: - DNS Install Sheet

struct DNSInstallSheet: View {
    let onDismiss: () -> Void
    @State private var showSafari = false

    private let profileURL = URL(string: "https://www.mediafire.com/file/ywlxicmiqzbxl6d/aurora_bypass.mobileconfig/file")!

    var body: some View {
        ZStack {
            AuroraBackground()
            VStack(spacing: 24) {

                RoundedRectangle(cornerRadius: 3)
                    .fill(Aurora.textSub.opacity(0.3))
                    .frame(width: 40, height: 4)
                    .padding(.top, 12)

                ZStack {
                    Circle()
                        .fill(Aurora.danger.opacity(0.15))
                        .frame(width: 70, height: 70)
                    Image(systemName: "shield.lefthalf.filled")
                        .font(.system(size: 30))
                        .foregroundStyle(Aurora.danger)
                }

                VStack(spacing: 8) {
                    Text("DNS Antiban")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(Aurora.textPrimary)
                    Text("Blocks anticheat & ban domains.\nAfter installing, go to Settings → VPN & Device Management → AimLock HZZ → Install.")
                        .font(Aurora.captionFont)
                        .foregroundStyle(Aurora.textSub)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)
                }

                VStack(alignment: .leading, spacing: 12) {
                    stepRow("1", "Tap Install DNS below")
                    stepRow("2", "Profile will open — tap Allow")
                    stepRow("3", "Settings → VPN & Device Management")
                    stepRow("4", "AimLock HZZ → Install → done")
                }
                .padding(.horizontal, 32)

                Spacer()

                Button {
                    showSafari = true
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "arrow.down.circle.fill")
                            .font(.system(size: 15, weight: .semibold))
                        Text("Install DNS")
                            .font(Aurora.bodyFont)
                            .foregroundStyle(.white)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(
                        LinearGradient(
                            colors: [Aurora.danger, Color(red: 1, green: 0.5, blue: 0.3)],
                            startPoint: .leading, endPoint: .trailing
                        )
                    )
                    .clipShape(RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous))
                    .shadow(color: Aurora.danger.opacity(0.4), radius: 10)
                }
                .padding(.horizontal, Aurora.pad)
                .padding(.bottom, 40)
            }
        }
        .fullScreenCover(isPresented: $showSafari) {
            SafariView(url: profileURL)
                .ignoresSafeArea()
        }
    }

    @ViewBuilder
    private func stepRow(_ num: String, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(num)
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(Aurora.bg)
                .frame(width: 20, height: 20)
                .background(Aurora.purpleGlow)
                .clipShape(Circle())
            Text(text)
                .font(Aurora.captionFont)
                .foregroundStyle(Aurora.textSub)
        }
    }
}

// MARK: - Safari View

struct SafariView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> SFSafariViewController {
        let config = SFSafariViewController.Configuration()
        config.entersReaderIfAvailable = false
        return SFSafariViewController(url: url, configuration: config)
    }
    func updateUIViewController(_ uvc: SFSafariViewController, context: Context) {}
}

// MARK: - ShareSheet

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uvc: UIActivityViewController, context: Context) {}
}
