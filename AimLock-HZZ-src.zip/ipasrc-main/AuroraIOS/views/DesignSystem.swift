import SwiftUI

// MARK: - AURORA IOS Design System
// Theme: Deep purple / black glowing futuristic

enum Aurora {

    // MARK: - Colours
    static let bg          = Color(red: 0.04, green: 0.02, blue: 0.08)      // near-black purple
    static let bgCard      = Color(red: 0.07, green: 0.03, blue: 0.14)      // card dark purple
    static let bgCardHigh  = Color(red: 0.10, green: 0.04, blue: 0.18)      // elevated card
    static let purple      = Color(red: 0.55, green: 0.15, blue: 0.90)      // main purple
    static let purpleDim   = Color(red: 0.35, green: 0.08, blue: 0.60)      // dim purple
    static let purpleGlow  = Color(red: 0.72, green: 0.30, blue: 1.00)      // glow purple
    static let border      = Color(red: 0.45, green: 0.10, blue: 0.75).opacity(0.4)
    static let borderGlow  = Color(red: 0.72, green: 0.30, blue: 1.00).opacity(0.7)
    static let textPrimary = Color.white
    static let textSub     = Color(white: 0.65)
    static let success     = Color(red: 0.20, green: 0.85, blue: 0.45)
    static let danger      = Color(red: 1.00, green: 0.28, blue: 0.28)
    static let warn        = Color(red: 1.00, green: 0.75, blue: 0.10)

    // MARK: - Typography
    static let titleFont   = Font.system(size: 30, weight: .bold,    design: .rounded)
    static let headFont    = Font.system(size: 18, weight: .bold,    design: .rounded)
    static let bodyFont    = Font.system(size: 15, weight: .semibold,design: .rounded)
    static let captionFont = Font.system(size: 12, weight: .regular, design: .rounded)
    static let labelFont   = Font.system(size: 11, weight: .semibold,design: .rounded)
    static let monoFont    = Font.system(size: 13, weight: .medium,  design: .monospaced)

    // MARK: - Shape
    static let radius: CGFloat      = 16
    static let radiusSmall: CGFloat = 10
    static let pad: CGFloat         = 20
}

// MARK: - Aurora Background

struct AuroraBackground: View {
    var body: some View {
        ZStack {
            Aurora.bg.ignoresSafeArea()
            // Glow orb top
            RadialGradient(
                colors: [Aurora.purple.opacity(0.18), .clear],
                center: .top,
                startRadius: 0,
                endRadius: 350
            )
            .ignoresSafeArea()
            // Glow orb bottom
            RadialGradient(
                colors: [Aurora.purpleDim.opacity(0.10), .clear],
                center: .bottom,
                startRadius: 0,
                endRadius: 280
            )
            .ignoresSafeArea()
        }
    }
}

// MARK: - Glow Card

struct GlowCard<Content: View>: View {
    var glowing: Bool = false
    @ViewBuilder var content: () -> Content

    var body: some View {
        content()
            .background(Aurora.bgCard)
            .clipShape(RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous)
                    .strokeBorder(
                        glowing ? Aurora.borderGlow : Aurora.border,
                        lineWidth: glowing ? 1.2 : 0.8
                    )
            )
            .shadow(
                color: glowing ? Aurora.purple.opacity(0.35) : Aurora.purple.opacity(0.10),
                radius: glowing ? 14 : 6, x: 0, y: 0
            )
    }
}

// MARK: - Aurora Toggle Row

struct AuroraToggle: View {
    let label: String
    let icon: String
    @Binding var value: Bool

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(value ? Aurora.purple.opacity(0.25) : Color.white.opacity(0.06))
                    .frame(width: 34, height: 34)
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(value ? Aurora.purpleGlow : Aurora.textSub)
            }
            Text(label)
                .font(Aurora.bodyFont)
                .foregroundStyle(value ? Aurora.textPrimary : Aurora.textSub)
            Spacer()
            // Custom toggle
            ZStack {
                Capsule()
                    .fill(value ? Aurora.purple : Color.white.opacity(0.10))
                    .frame(width: 46, height: 26)
                    .shadow(color: value ? Aurora.purple.opacity(0.6) : .clear, radius: 6)
                Circle()
                    .fill(.white)
                    .frame(width: 20, height: 20)
                    .shadow(color: .black.opacity(0.3), radius: 3)
                    .offset(x: value ? 10 : -10)
                    .animation(.spring(response: 0.28, dampingFraction: 0.7), value: value)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .contentShape(Rectangle())
        .onTapGesture { value.toggle() }
    }
}

// MARK: - Section Header

struct AuroraSectionHeader: View {
    let title: String
    var body: some View {
        Text(title.uppercased())
            .font(Aurora.labelFont)
            .foregroundStyle(Aurora.purpleGlow)
            .padding(.top, 6)
            .padding(.bottom, 2)
            .padding(.horizontal, 4)
    }
}

// MARK: - Glow Button

struct GlowButton: View {
    let label: String
    var icon: String? = nil
    var loading: Bool = false
    var disabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                if loading {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .scaleEffect(0.8)
                        .tint(.white)
                } else if let icon {
                    Image(systemName: icon)
                        .font(.system(size: 15, weight: .semibold))
                }
                Text(label)
                    .font(Aurora.bodyFont)
                    .foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background(
                Group {
                    if disabled || loading {
                        Aurora.purpleDim.opacity(0.5)
                    } else {
                        LinearGradient(
                            colors: [Aurora.purple, Aurora.purpleGlow],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    }
                }
            )
            .clipShape(RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous))
            .shadow(color: (disabled || loading) ? .clear : Aurora.purple.opacity(0.55), radius: 12)
            .overlay(
                RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous)
                    .strokeBorder(Aurora.borderGlow.opacity(disabled ? 0 : 0.5), lineWidth: 1)
            )
        }
        .disabled(disabled || loading)
    }
}

// MARK: - Segment Button

struct AuroraSegment<T: Hashable>: View {
    let options: [(label: String, value: T)]
    @Binding var selected: T

    var body: some View {
        HStack(spacing: 6) {
            ForEach(options, id: \.value) { opt in
                Button {
                    selected = opt.value
                } label: {
                    Text(opt.label)
                        .font(Aurora.captionFont)
                        .foregroundStyle(selected == opt.value ? .white : Aurora.textSub)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity)
                        .background(
                            selected == opt.value
                                ? Aurora.purple
                                : Color.white.opacity(0.07)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                        .shadow(color: selected == opt.value ? Aurora.purple.opacity(0.5) : .clear, radius: 6)
                }
            }
        }
    }
}

// MARK: - Status Badge

struct StatusBadge: View {
    let text: String
    let color: Color

    var body: some View {
        Text(text)
            .font(Aurora.captionFont)
            .foregroundStyle(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(color.opacity(0.15))
            .clipShape(Capsule())
            .overlay(Capsule().strokeBorder(color.opacity(0.4), lineWidth: 0.8))
    }
}
