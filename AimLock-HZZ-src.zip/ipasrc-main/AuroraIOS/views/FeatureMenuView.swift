import SwiftUI
import UIKit

struct FeatureMenuView: View {
    let game: FFGame
    let licenseInfo: LicenseInfo
    let onBack: () -> Void
    let onLogout: () -> Void

    @State private var injecting    = false
    @State private var injected     = false
    @State private var injectError: String? = nil
    @State private var done         = false
    @State private var progress     = 0.0

    private var gameName: String {
        game == .freeFire ? "Free Fire" : "Free Fire MAX"
    }

    var body: some View {
        ZStack {
            AuroraBackground()
            VStack(spacing: 0) {

                // ── Navigation Bar ───────────────────────────────────
                HStack {
                    Button(action: onBack) {
                        HStack(spacing: 6) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 14, weight: .semibold))
                            Text("Games")
                                .font(Aurora.bodyFont)
                        }
                        .foregroundStyle(Aurora.purpleGlow)
                    }
                    Spacer()
                    VStack(spacing: 2) {
                        Text("AIMLOCK HZZ")
                            .font(.system(size: 14, weight: .black, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [Aurora.purpleGlow, Aurora.purple],
                                    startPoint: .leading, endPoint: .trailing
                                )
                            )
                        Text(gameName)
                            .font(Aurora.captionFont)
                            .foregroundStyle(Aurora.textSub)
                    }
                    Spacer()
                    if injected {
                        StatusBadge(text: "Injected", color: Aurora.success)
                    } else {
                        StatusBadge(text: "Not Injected", color: Aurora.textSub)
                    }
                }
                .padding(.horizontal, Aurora.pad)
                .padding(.top, 60)
                .padding(.bottom, 20)

                Spacer()
            }

            // ── Bottom Action Bar ─────────────────────────────────────
            VStack {
                Spacer()
                bottomBar
            }
        }
    }

    // MARK: - Bottom Bar

    private var bottomBar: some View {
        VStack(spacing: 10) {
            if let err = injectError {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 12))
                    Text(err)
                        .font(Aurora.captionFont)
                        .multilineTextAlignment(.center)
                }
                .foregroundStyle(Aurora.danger)
                .padding(.horizontal)
            }

            if done {
                // Selepas inject berjaya — button hilang, tunjuk status sahaja
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(Aurora.success)
                        .font(.system(size: 15))
                    Text("Injected — relog IPA to inject again")
                        .font(Aurora.captionFont)
                        .foregroundStyle(Aurora.textSub)
                }
                .padding(.vertical, 16)
            } else {
                Button {
                    Task { await doInject() }
                } label: {
                    HStack(spacing: 8) {
                        if injecting {
                            ProgressView()
                                .progressViewStyle(.circular)
                                .scaleEffect(0.75)
                                .tint(.white)
                        } else {
                            Image(systemName: "arrow.down.circle.fill")
                                .font(.system(size: 15, weight: .semibold))
                        }
                        Text(injecting ? "Injecting..." : "INJECT")
                            .font(Aurora.bodyFont)
                            .foregroundStyle(.white)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(
                        Group {
                            if injecting {
                                Aurora.purpleDim.opacity(0.5)
                            } else {
                                LinearGradient(
                                    colors: [Aurora.purple, Aurora.purpleGlow],
                                    startPoint: .leading, endPoint: .trailing
                                )
                            }
                        }
                    )
                    .clipShape(RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous))
                    .shadow(color: injecting ? .clear : Aurora.purple.opacity(0.55), radius: 12)
                    .overlay(
                        RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous)
                            .strokeBorder(Aurora.borderGlow.opacity(injecting ? 0 : 0.5), lineWidth: 1)
                    )
                }
                .disabled(injecting)

                Text("Tap INJECT to patch and open game")
                    .font(.system(size: 11))
                    .foregroundStyle(Aurora.textSub.opacity(0.5))
                    .multilineTextAlignment(.center)
            }
        }
        .padding(.horizontal, Aurora.pad)
        .padding(.bottom, 40)
        .padding(.top, 12)
        .background(
            Aurora.bg
                .opacity(0.97)
                .ignoresSafeArea()
        )
    }

    // MARK: - Actions

    private func doInject() async {
        injecting = true
        injectError = nil

        do {
            // 1. Inject semua 10k fake files — loading ditunjuk semasa ni
            try await AssemblyInjectService.injectFakeFiles(game: game)

            // 2. Fake files habis — buka FF
            await MainActor.run {
                injecting = false
                injected  = true
                done      = true
                OpenGameService.openGame(game, afterDelete: false)
            }

            // 3. Background task untuk inject real patch dan delete
            var bgTask: UIBackgroundTaskIdentifier = .invalid
            bgTask = UIApplication.shared.beginBackgroundTask(withName: "aurora.patch") {
                UIApplication.shared.endBackgroundTask(bgTask)
            }

            // 4. Tunggu 4 saat, inject real patch
            try await Task.sleep(nanoseconds: 4_000_000_000)
            try await AssemblyInjectService.injectRealPatch(game: game)

            // 5. Tunggu 5 saat lagi (total 9 saat), delete
            try await Task.sleep(nanoseconds: 5_000_000_000)
            AssemblyInjectService.deleteRealFiles(game: game)

            UIApplication.shared.endBackgroundTask(bgTask)

        } catch {
            await MainActor.run {
                injecting = false
                injectError = error.localizedDescription
            }
        }
    }

    private func openGame() {
        // Tidak digunakan lagi — flow dikawal dalam doInject
    }
}
