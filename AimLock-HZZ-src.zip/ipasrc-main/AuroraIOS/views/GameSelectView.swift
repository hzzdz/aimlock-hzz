import SwiftUI

struct GameSelectView: View {
    let licenseInfo: LicenseInfo
    let onLogout: () -> Void

    @State private var selectedGame: FFGame? = nil
    @State private var now = Date()
    @State private var showDNSSheet = false
    @State private var dnsInstalling = false

    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        if let game = selectedGame {
            FeatureMenuView(
                game: game,
                licenseInfo: licenseInfo,
                onBack: { selectedGame = nil },
                onLogout: onLogout
            )
        } else {
            mainContent
        }
    }

    private var mainContent: some View {
        ZStack {
            AuroraBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {

                    // ── Top Bar ───────────────────────────────────────
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("AIMLOCK HZZ")
                                .font(.system(size: 17, weight: .black, design: .rounded))
                                .foregroundStyle(
                                    LinearGradient(
                                        colors: [Aurora.purpleGlow, Aurora.purple],
                                        startPoint: .leading, endPoint: .trailing
                                    )
                                )
                            Text(LicenseService.maskedKey(licenseInfo.key))
                                .font(Aurora.monoFont)
                                .foregroundStyle(Aurora.textSub)
                        }
                        Spacer()
                        Button {
                            LicenseService.logout()
                            onLogout()
                        } label: {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(Aurora.textSub)
                                .padding(10)
                                .background(Aurora.bgCard)
                                .clipShape(Circle())
                                .overlay(Circle().strokeBorder(Aurora.border, lineWidth: 0.8))
                        }
                    }
                    .padding(.horizontal, Aurora.pad)
                    .padding(.top, 60)
                    .padding(.bottom, 20)

                    // ── Key Info Card ─────────────────────────────────
                    GlowCard {
                        VStack(spacing: 0) {
                            infoRow(
                                icon: "clock.fill",
                                label: "EXPIRES",
                                value: expiryText,
                                valueColor: expiryColor
                            )
                            Divider().background(Aurora.border).padding(.horizontal, 14)
                            infoRow(
                                icon: "iphone",
                                label: "DEVICE",
                                value: DeviceID.iPhoneModel
                            )
                            Divider().background(Aurora.border).padding(.horizontal, 14)
                            infoRow(
                                icon: "cpu",
                                label: "iOS VERSION",
                                value: DeviceID.iOSVersion,
                                valueColor: iosSupported ? Aurora.success : Aurora.danger
                            )
                        }
                    }
                    .padding(.horizontal, Aurora.pad)
                    .padding(.bottom, 24)

                    // ── DNS Banner ────────────────────────────────────
                    Button {
                        showDNSSheet = true
                    } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(Aurora.danger.opacity(0.15))
                                    .frame(width: 36, height: 36)
                                Image(systemName: "shield.slash.fill")
                                    .font(.system(size: 16))
                                    .foregroundStyle(Aurora.danger)
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Please install DNS Antiban")
                                    .font(Aurora.bodyFont)
                                    .foregroundStyle(Aurora.textPrimary)
                                Text("Tap to install → Settings > VPN")
                                    .font(Aurora.captionFont)
                                    .foregroundStyle(Aurora.textSub)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(Aurora.textSub.opacity(0.5))
                        }
                        .padding(14)
                        .background(Aurora.danger.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: Aurora.radiusSmall, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: Aurora.radiusSmall, style: .continuous)
                                .strokeBorder(Aurora.danger.opacity(0.3), lineWidth: 1)
                        )
                    }
                    .padding(.horizontal, Aurora.pad)
                    .padding(.bottom, 16)

                    // ── Select Game ───────────────────────────────────
                    VStack(spacing: 6) {
                        Text("SELECT GAME")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(Aurora.textSub)
                        Text("Choose your Free Fire version")
                            .font(Aurora.captionFont)
                            .foregroundStyle(Aurora.textSub.opacity(0.5))
                    }
                    .padding(.bottom, 16)

                    VStack(spacing: 12) {
                        gameCard(game: .freeFire,    name: "Free Fire",     color: Aurora.success)
                        gameCard(game: .freefireMax, name: "Free Fire MAX", color: Aurora.purpleGlow)
                    }
                    .padding(.horizontal, Aurora.pad)

                    Spacer(minLength: 40)

                    // ── Footer ────────────────────────────────────────
                    VStack(spacing: 4) {
                        HStack(spacing: 5) {
                            Image(systemName: "paperplane.fill").font(.system(size: 10))
                            Text("t.me/aurora_ios").font(Aurora.captionFont)
                        }
                        .foregroundStyle(Aurora.purpleGlow.opacity(0.6))
                        Text("Join for updates, keys & support")
                            .font(.system(size: 10))
                            .foregroundStyle(Aurora.textSub.opacity(0.35))
                    }
                    .padding(.bottom, 40)
                }
            }
        }
        .onReceive(timer) { _ in now = Date() }
        .sheet(isPresented: $showDNSSheet) {
            DNSInstallSheet(onDismiss: { showDNSSheet = false })
        }
    }

    // MARK: - Computed

    private var expiryText: String {
        guard let exp = licenseInfo.expiryDate else { return "Lifetime" }
        let diff = exp.timeIntervalSince(now)
        if diff <= 0 { return "Expired" }
        let days = Int(diff / 86400)
        let hours = Int((diff.truncatingRemainder(dividingBy: 86400)) / 3600)
        let mins  = Int((diff.truncatingRemainder(dividingBy: 3600)) / 60)
        let secs  = Int(diff.truncatingRemainder(dividingBy: 60))
        if days > 0 { return "\(days)d \(hours)h \(mins)m" }
        if hours > 0 { return "\(hours)h \(mins)m \(secs)s" }
        return "\(mins)m \(secs)s"
    }

    private var expiryColor: Color {
        guard let exp = licenseInfo.expiryDate else { return Aurora.success }
        let diff = exp.timeIntervalSince(now)
        if diff <= 0    { return Aurora.danger }
        if diff < 3600  { return Aurora.danger }
        if diff < 86400 { return Aurora.warn }
        return Aurora.success
    }

    private var iosSupported: Bool {
        let ver = DeviceID.iOSVersion
        let parts = ver.split(separator: ".").compactMap { Int($0) }
        let major = parts.first ?? 0
        let minor = parts.dropFirst().first ?? 0
        let patch = parts.dropFirst(2).first ?? 0
        return ExploitSupportPolicy.supportsKernelExploit(major: major, minor: minor, patch: patch)
            || major == 26 || major == 27
    }

    // MARK: - Views

    @ViewBuilder
    private func infoRow(icon: String, label: String, value: String, valueColor: Color = .white) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 13))
                .foregroundStyle(Aurora.purpleDim)
                .frame(width: 20)
            Text(label)
                .font(Aurora.captionFont)
                .foregroundStyle(Aurora.textSub)
            Spacer()
            Text(value)
                .font(Aurora.monoFont)
                .foregroundStyle(valueColor)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
    }

    @ViewBuilder
    private func gameCard(game: FFGame, name: String, color: Color) -> some View {
        let installed = ContainerStore.resolveAppContainerPath(bundleID: game.bundleID) != nil
        Button { if installed { selectedGame = game } } label: {
            HStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(color.opacity(0.15))
                        .frame(width: 50, height: 50)
                    Image(systemName: "gamecontroller.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(color)
                }
                Text(name)
                    .font(Aurora.bodyFont)
                    .foregroundStyle(Aurora.textPrimary)
                Spacer()
                if installed {
                    HStack(spacing: 5) {
                        Circle().fill(Aurora.success).frame(width: 6, height: 6)
                        Text("Installed").font(Aurora.captionFont).foregroundStyle(Aurora.success)
                    }
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Aurora.textSub.opacity(0.5))
                } else {
                    StatusBadge(text: "Not Found", color: Aurora.warn)
                }
            }
            .padding(16)
            .background(Aurora.bgCard)
            .clipShape(RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: Aurora.radius, style: .continuous)
                    .strokeBorder(installed ? Aurora.border : Color.white.opacity(0.05), lineWidth: 0.8)
            )
            .shadow(color: installed ? color.opacity(0.12) : .clear, radius: 8)
            .opacity(installed ? 1 : 0.5)
        }
        .disabled(!installed)
    }
}
