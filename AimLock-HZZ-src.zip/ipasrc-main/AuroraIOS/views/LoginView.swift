import Darwin
import SwiftUI

struct LoginView: View {
    @State private var keyInput:   String  = ""
    @State private var validating: Bool    = false
    @State private var error:      String? = nil

    let onSuccess: (LicenseInfo) -> Void

    private var iosSupport: (text: String, supported: Bool) {
        let ver = DeviceID.iOSVersion
        let parts = ver.split(separator: ".").compactMap { Int($0) }
        let major = parts.first ?? 0
        let minor = parts.dropFirst().first ?? 0
        let patch = parts.dropFirst(2).first ?? 0
        var size = 0
        sysctlbyname("kern.osversion", nil, &size, nil, 0)
        var build = [CChar](repeating: 0, count: size)
        sysctlbyname("kern.osversion", &build, &size, nil, 0)
        let buildStr = String(cString: build)
        let supported = ExploitSupportPolicy.isSupported(
            major: major, minor: minor, patch: patch,
            build: buildStr
        )
        return (ver, supported)
    }

    var body: some View {
        ZStack {
            AuroraBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    Spacer(minLength: 70)

                    // ── Logo ──────────────────────────────────────────
                    VStack(spacing: 6) {
                        Text("AIMLOCK HZZ")
                            .font(.system(size: 32, weight: .black, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [Aurora.purpleGlow, Aurora.purple],
                                    startPoint: .leading, endPoint: .trailing
                                )
                            )
                            .shadow(color: Aurora.purple.opacity(0.6), radius: 10)

                        Text("Free Fire External Cheat")
                            .font(Aurora.captionFont)
                            .foregroundStyle(Aurora.textSub)
                    }
                    .padding(.bottom, 40)

                    // ── Key Input ─────────────────────────────────────
                    GlowCard(glowing: !keyInput.isEmpty) {
                        VStack(alignment: .leading, spacing: 14) {
                            Text("LICENSE KEY")
                                .font(Aurora.labelFont)
                                .foregroundStyle(Aurora.purpleGlow)

                            HStack(spacing: 12) {
                                Image(systemName: "key.fill")
                                    .font(.system(size: 13))
                                    .foregroundStyle(Aurora.purpleDim)
                                TextField("", text: $keyInput)
                                    .font(Aurora.monoFont)
                                    .foregroundStyle(Aurora.textPrimary)
                                    .autocapitalization(.allCharacters)
                                    .autocorrectionDisabled()
                                    .keyboardType(.asciiCapable)
                                    .tint(Aurora.purpleGlow)
                                    .placeholder(when: keyInput.isEmpty) {
                                        Text("XXXX-XXXX-XXXX-XXXX")
                                            .font(Aurora.monoFont)
                                            .foregroundStyle(Aurora.textSub.opacity(0.5))
                                    }
                            }
                            .padding(14)
                            .background(Aurora.bgCardHigh)
                            .clipShape(RoundedRectangle(cornerRadius: Aurora.radiusSmall, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: Aurora.radiusSmall, style: .continuous)
                                    .strokeBorder(
                                        error != nil ? Aurora.danger.opacity(0.6) :
                                        (!keyInput.isEmpty ? Aurora.borderGlow : Aurora.border),
                                        lineWidth: 1
                                    )
                            )

                            if let error {
                                HStack(spacing: 6) {
                                    Image(systemName: "exclamationmark.triangle.fill")
                                        .font(.system(size: 11))
                                    Text(error)
                                        .font(Aurora.captionFont)
                                }
                                .foregroundStyle(Aurora.danger)
                                .padding(.top, 2)
                            }
                        }
                        .padding(Aurora.pad)
                    }
                    .padding(.horizontal, Aurora.pad)
                    .padding(.bottom, 14)

                    // ── Device Info ───────────────────────────────────
                    GlowCard {
                        VStack(spacing: 0) {
                            infoRow(
                                icon: "iphone",
                                label: "DEVICE",
                                value: DeviceID.iPhoneModel
                            )
                            Divider()
                                .background(Aurora.border)
                                .padding(.horizontal, 14)
                            infoRow(
                                icon: "cpu",
                                label: "iOS VERSION",
                                value: iosSupport.text,
                                badge: iosSupport.supported ? ("Supported", Aurora.success) : ("Unsupported", Aurora.danger)
                            )
                        }
                    }
                    .padding(.horizontal, Aurora.pad)
                    .padding(.bottom, 24)

                    // ── Button ────────────────────────────────────────
                    GlowButton(
                        label: validating ? "Validating..." : "ACTIVATE",
                        icon: validating ? nil : "checkmark.shield.fill",
                        loading: validating,
                        disabled: keyInput.trimmingCharacters(in: .whitespaces).isEmpty
                    ) {
                        Task { await validate() }
                    }
                    .padding(.horizontal, Aurora.pad)
                    .padding(.bottom, 20)

                    // ── Footer ────────────────────────────────────────
                    VStack(spacing: 4) {
                        Text("t.me/aurora_ios")
                            .font(Aurora.captionFont)
                            .foregroundStyle(Aurora.purpleGlow.opacity(0.7))
                        Text("Join for updates & support")
                            .font(.system(size: 10, weight: .regular))
                            .foregroundStyle(Aurora.textSub.opacity(0.5))
                    }
                    .padding(.bottom, 50)
                }
            }
        }
    }

    @ViewBuilder
    private func infoRow(
        icon: String,
        label: String,
        value: String,
        badge: (String, Color)? = nil
    ) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 13))
                .foregroundStyle(Aurora.purpleDim)
                .frame(width: 20)
            Text(label)
                .font(Aurora.captionFont)
                .foregroundStyle(Aurora.textSub)
            Spacer()
            if let badge {
                StatusBadge(text: badge.0, color: badge.1)
            } else {
                Text(value)
                    .font(Aurora.monoFont)
                    .foregroundStyle(Aurora.textPrimary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
    }

    private func validate() async {
        let key = keyInput.trimmingCharacters(in: .whitespaces)
        guard !key.isEmpty else { return }
        validating = true; error = nil
        do {
            let info = try await LicenseService.validate(key: key)
            await MainActor.run { validating = false; onSuccess(info) }
        } catch let e as LicenseError {
            await MainActor.run { validating = false; self.error = e.errorDescription }
        } catch {
            await MainActor.run { validating = false; self.error = "Network error" }
        }
    }
}

// MARK: - Placeholder extension
extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        @ViewBuilder placeholder: () -> Content
    ) -> some View {
        ZStack(alignment: .leading) {
            if shouldShow { placeholder() }
            self
        }
    }
}
